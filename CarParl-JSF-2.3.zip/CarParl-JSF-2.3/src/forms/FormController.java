package forms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean @SessionScoped
public class FormController {

	/*Events
	 ******************************************************** 0. Load vehicles regNumbers in the dropDownlist
	 * 1.btnAddRoadMap.click 
	 * 2. SelectCar 
	 * 3. BtnSave.click() 
	 */
	private List<String> regNumList;
	private String regNum;
//	private FormData formData= new FormData();
	public static final String IS_10_PSI ="IS-10-PSI"; 
	public static final String IS_11_PSI ="IS-11-PSI"; 
	public static final String IS_12_PSI ="IS-12-PSI"; 	
	
	public String getRegNum() {
		return regNum;
	}

	public void setRegNum(String regNum) {
		this.regNum = regNum;
	}
	public List<String> getRegNumList() {
		return regNumList;
	}

	public void setRegNumList(List<String> regNumList) {
		this.regNumList = regNumList;
	}

//	public String getVehicleBStringyRegNum(String registrationNumber) {
//		return this.formData.getMasterRepository().getVehicleByRegistrationNumber(registrationNumber).getRegistrationNumber();
//	}
//	
//	public FormData getFormData() {
//		return formData;
//	}
	
	@PostConstruct
	public void init() {
		regNumList = new ArrayList<String>();
		regNumList.add(IS_10_PSI);
		regNumList.add(IS_11_PSI);
		regNumList.add(IS_12_PSI);
	}

//	public void setformData(FormData formData) {
//		this.formData = formData;
//	}
//
//	public Vehicle getVehicle() {
//		return vehicle;
//	}
//
//	public void setVehicles(ArrayList<Vehicle> vehicles) {
//		this.vehicles = vehicles;
//	}
//	
	
}
