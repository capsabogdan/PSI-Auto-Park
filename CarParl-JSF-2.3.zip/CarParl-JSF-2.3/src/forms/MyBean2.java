package forms;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean @SessionScoped
public class MyBean2 {
	private String name;
	private String  state;
	private List<String> stateList;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<String> getStateList() {
		return stateList;
	}
	public void setStateList(List<String> stateList) {
		this.stateList = stateList;
	}
	
	@PostConstruct
	public void init() {
		stateList  = new ArrayList<String>();
		stateList.add("John");
		stateList.add("Maggie");
		stateList.add("Josh");
		
	}
}
