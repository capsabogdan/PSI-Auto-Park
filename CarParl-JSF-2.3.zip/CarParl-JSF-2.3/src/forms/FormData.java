package forms;

import java.util.List;

import com.carpark.model.entities.RoadMap;
import com.carpark.model.entities.RoadMapRow;
import com.carpark.model.entities.Vehicle;
import com.carpark.model.repository.DocumentRepository;
import com.carpark.model.repository.MasterRepository;

public class FormData {

	public static final String PEOPLE = "People";
	public static final String CARGO = "Cargo";
	public static final String BENZIN = "Benzin";
	public static final String DIESEL = "Diesel";
	
	
	public FormData() {
		super();
	}
	// colectia de obiecte-tinta obtinute in urma unei operatii de cautare
	private List<Vehicle> vehiclesList;
	
	// obiecte de tip Repository necesare pentru interogarea modelului
//	private MasterRepository masterRepository = new MasterRepository();
	private DocumentRepository documentRepository= new DocumentRepository();
	
//	public List<Vehicle> getVehiclesList() {
//		if(this.vehiclesList == null) {
//			this.vehiclesList = this.masterRepository.getAllVehicles();
//		}
//		return vehiclesList;
//	}
	public void setVehiclesList(List<Vehicle> vehiclesList) {
		this.vehiclesList = vehiclesList;
	}
	
//	public MasterRepository getMasterRepository() {
//		return masterRepository;
//	}
	
	public DocumentRepository getDocumentRepository() {
		return documentRepository;
	}

	public static String getPeople() {
		return PEOPLE;
	}
	public static String getCargo() {
		return CARGO;
	}
	public static String getBenzin() {
		return BENZIN;
	}
	public static String getDiesel() {
		return DIESEL;
	}
}
	
